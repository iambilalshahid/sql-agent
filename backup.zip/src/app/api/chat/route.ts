import { NextRequest, NextResponse } from "next/server";
import { HumanMessage } from "@langchain/core/messages";
import { getAgent } from "@/lib/agent";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
    try {
        const { message } = await req.json();
        if (!message || typeof message !== "string") {
            return NextResponse.json({ error: "Missing 'message' string in body" }, { status: 400 });
        }

        const agent = await getAgent(); // agent now uses getCurrentUser inside tool
        const result = await agent.invoke({
            messages: [new HumanMessage(message)],
        });

        const structured = (result as { structuredResponse?: unknown }).structuredResponse;

        if (!structured) {
            const last = result.messages[result.messages.length - 1];
            return NextResponse.json({
                summary: typeof last.content === "string" ? last.content : JSON.stringify(last.content),
                uiType: "text",
            });
        }

        return NextResponse.json(structured);
    } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        return NextResponse.json({ error: message }, { status: 500 });
    }
}
